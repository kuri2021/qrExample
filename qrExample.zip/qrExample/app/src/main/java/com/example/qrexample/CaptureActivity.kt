package com.example.qrexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class CaptureActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_capture)
    }
}